'''
Created on 13.12.2020

@author: wakl8754
@references: 
    https://www.journaldev.com/14444/python-exception-handling-try-except
    https://www.journaldev.com/14454/python-custom-exception
'''

class RMException(Exception):
    '''
    @brief: Requirement management specific exception class
    '''
    pass

            